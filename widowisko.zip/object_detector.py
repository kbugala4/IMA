#! /usr/bin/env python
# -*- coding: utf8 -*-

import rospy
from sensor_msgs.msg import PointCloud2, Image
from geometry_msgs.msg import TransformStamped

from visualization_msgs.msg import Marker,MarkerArray

import numpy as np
import ros_numpy as rnp
import cv2
from cv_bridge import CvBridge
from math import sqrt
import tf2_ros

import glob
import os

from mask_rcnn_ros.srv import DetectObjects

detect_service = None
cv_bridge = None
marker_pub = None
iterator = 1
detected_bottles = []

def tf2np(tr):
    from pyquaternion import Quaternion as Q
    ret = np.eye(4,4)
    r = tr.transform.rotation
    t = tr.transform.translation
    R = Q(r.w, r.x, r.y, r.z).rotation_matrix
    T = np.array([t.x, t.y, t.z])

    return R, T

def colorize(xyz, zmin = 0, zmax = 3):
    zrng = zmax - zmin
    tmpz = xyz[:,:,2].copy()
    tmpz = ((tmpz - zmin) / zrng * 255)
    tmpz = np.clip(tmpz, 0, 255).astype(np.uint8)

    return cv2.applyColorMap(tmpz, cv2.COLORMAP_JET)

def pc2rgbxyz(points_msg):
    pc = rnp.numpify(points_msg)
    w = points_msg.width
    h = points_msg.height
    xyz = pc.view('<f4').reshape(h,w,pc.itemsize // 4)[:,:,0:3]
    rgb = pc['rgb'].copy().view('<u1').reshape(h,w,4)[:,:,0:3]

    return rgb, xyz

############################################################
# Przetwarzanie chmury punktów
############################################################

def process(score, class_id, class_name, mask, xyz, trans):
    list_of_widths = []
    x_list = []
    z_list = []
    points = xyz[mask!=0]
    c = np.nanmean(points, axis=0)
    R, T = tf2np(trans)
    cen = np.matmul(R, c) + T
    # global detected_bottles
    # duplicate = 0
    # for bottle in detected_bottles:
    #     distance = sqrt((bottle[0]-cen[0])**2+(bottle[1]-cen[1])**2+(bottle[2]-cen[2])**2)
    #     if distance < 0.1:
    #         duplicate = 1
    #         break

    rospy.loginfo("Detected %s at %f, %f, %f", class_name, cen[0], cen[1], cen[2])
    detected_bottles.append(cen)

    global iterator
    for point in points:
        x_list.append(point[0])
        z_list.append(point[1])
    # x_list = point[:,0]
    x_list.sort()
    z_list.sort()
    # print(x_list)
    width = x_list[int(len(x_list)*0.9)]-x_list[int(len(x_list)*0.1)]
    height = z_list[int(len(z_list)*0.9)]-z_list[int(len(z_list)*0.1)]
    print("Width: " + str(width) + "   Height: " + str(height))

     


    marker_ = Marker()
    marker_.header.frame_id = "/odom"
    marker_.type = marker_.CYLINDER
    marker_.action = marker_.ADD

    marker_.pose.position.x = cen[0]
    marker_.pose.position.y = cen[1]
    marker_.pose.position.z = cen[2]
    marker_.pose.orientation.x = 0
    marker_.pose.orientation.y = 0
    marker_.pose.orientation.z = 0
    marker_.pose.orientation.w = 1

    marker_.scale.x = 0.1
    marker_.scale.y = 0.1
    marker_.scale.z = 0.3
    marker_.color.a = 0.5
    marker_.color.r = 1.0
    marker_.color.g = 0.0
    marker_.color.b = 0.0

    # każdy obiekt musi dostać unikalne id!
    marker_.id = iterator
    iterator += 1

    return marker_

    

def callback(points_msg):
    global detect_service

    while True:
        try:
            trans = tfBuffer.lookup_transform(target_frame, points_msg.header.frame_id, points_msg.header.stamp)
            break
        except:
            print("Retry tf lookup")
            rospy.sleep(0.1)
    
    # zamiana chmury punktów na obraz kolorowy oraz macierz współrzędnych
    rgb, xyz = pc2rgbxyz(points_msg)
    
    try:
        image_msg = cv_bridge.cv2_to_imgmsg(rgb, 'bgr8')
        image_msg.header = points_msg.header
        resp = detect_service(image_msg)
        r = resp.result
        rospy.loginfo("Detected %d objects", len(r.scores))

        marker_array_msg = MarkerArray()

        # process detections
        for sc, ci, cn, ms in zip(r.scores, r.class_ids, r.class_names, r.masks):
            mask = cv_bridge.imgmsg_to_cv2(ms, 'mono8')
            points = xyz[mask!=0]
            c = np.nanmean(points, axis=0)
            R, T = tf2np(trans)
            cen = np.matmul(R, c) + T
            global detected_bottles
            duplicate = 0
            distance = 1
            for bottle in detected_bottles:
                distance = sqrt((bottle[0]-cen[0])**2+(bottle[1]-cen[1])**2+(bottle[2]-cen[2])**2)
                if distance < 0.2:
                    duplicate = 1
                    break
            if not duplicate:
            	if cn == "bottle":
                    marker = process(sc, ci, cn, mask, xyz, trans)
                    marker_array_msg.markers.append(marker) 
                else:
                	print("Sign detected! Marker won't be placed")
            else:
                print("Duplicate detected! Marker won't be placed")
        marker_pub.publish(marker_array_msg)
    except rospy.ServiceException as e:
        print("Service call failed: %s"%e)

    return


if __name__ == '__main__':
    rospy.init_node('symbol_detector', anonymous=True)

    target_frame = rospy.get_param('~target_frame', 'odom')
    print("Target frame: " +str(target_frame))

    # przygotowanie i wstępne wypełnienie bufora transformacji
    tfBuffer = tf2_ros.Buffer(rospy.Duration(120))
    listener = tf2_ros.TransformListener(tfBuffer)

    cv_bridge = CvBridge()

    rospy.loginfo("Filling TF buffer")
    rospy.sleep(2)


    rospy.loginfo("Subscribing to topics")

    marker_pub = rospy.Publisher("/visualization_marker", MarkerArray, queue_size = 2)
    points_sub = rospy.Subscriber('points', PointCloud2, callback, queue_size=1)


    rospy.wait_for_service('detect_objects')
    detect_service = rospy.ServiceProxy('detect_objects', DetectObjects)

    rospy.spin()
